"""
Create a self-signed CA and a signer cert, create a simple unsigned PDF, and sign it using pyhanko.
Outputs:
 - samples/unsigned_sample.pdf
 - samples/ca.pem
 - samples/signer.pem
 - samples/signer.key
 - samples/signed_by_pyhanko.pdf

This is a Python-only flow (no OpenSSL required).
"""
from pathlib import Path
import sys
import logging

try:
    from cryptography.hazmat.primitives.asymmetric import rsa  # type: ignore
    from cryptography.hazmat.primitives import serialization, hashes  # type: ignore
    from cryptography.x509 import NameOID  # type: ignore
    import cryptography.x509 as x509  # type: ignore
    from datetime import datetime, timedelta
    from reportlab.pdfgen import canvas  # type: ignore
    from pyhanko.sign import signers  # type: ignore
    from pyhanko.sign.general import load_cert_from_pemder  # type: ignore
except Exception as e:
    print("Thiếu thư viện cần thiết. Hãy cài dependencies trong requirements.txt và chạy lại. Lỗi:", e)
    sys.exit(2)

LOG = logging.getLogger("create_signed_pdf")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

OUT_DIR = Path(__file__).resolve().parents[1]
SAMPLES = OUT_DIR / 'samples'
SAMPLES.mkdir(parents=True, exist_ok=True)

UNSIGNED_PDF = SAMPLES / 'unsigned_sample.pdf'
SIGNED_PDF = SAMPLES / 'signed_by_pyhanko.pdf'
CA_KEY_PEM = SAMPLES / 'ca.key'
CA_PEM = SAMPLES / 'ca.pem'
SIGNER_KEY_PEM = SAMPLES / 'signer.key'
SIGNER_PEM = SAMPLES / 'signer.pem'

# 1) Generate CA key and cert
LOG.info('Tạo CA key và chứng chỉ...')
ca_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
ca_name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, u"Test CA")])
ca_cert = (
    x509.CertificateBuilder()
    .subject_name(ca_name)
    .issuer_name(ca_name)
    .public_key(ca_key.public_key())
    .serial_number(x509.random_serial_number())
    .not_valid_before(datetime.utcnow() - timedelta(days=1))
    .not_valid_after(datetime.utcnow() + timedelta(days=3650))
    .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
    .sign(ca_key, hashes.SHA256())
)

# 2) Generate signer key + cert signed by CA
LOG.info('Tạo signer key và chứng chỉ...')
signer_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
signer_name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, u"Test Signer")])
signer_cert = (
    x509.CertificateBuilder()
    .subject_name(signer_name)
    .issuer_name(ca_cert.subject)
    .public_key(signer_key.public_key())
    .serial_number(x509.random_serial_number())
    .not_valid_before(datetime.utcnow() - timedelta(days=1))
    .not_valid_after(datetime.utcnow() + timedelta(days=365))
    # Mark as end-entity and include appropriate key usage for signing
    .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
    .add_extension(
        x509.KeyUsage(
            digital_signature=True,
            content_commitment=True,  # nonRepudiation
            key_encipherment=False,
            data_encipherment=False,
            key_agreement=False,
            key_cert_sign=False,
            crl_sign=False,
            encipher_only=False,
            decipher_only=False,
        ),
        critical=True,
    )
    .add_extension(x509.SubjectKeyIdentifier.from_public_key(signer_key.public_key()), critical=False)
    .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_key.public_key()), critical=False)
    .sign(ca_key, hashes.SHA256())
)

# 3) Write keys and certs to files
LOG.info('Ghi các file PEM vào samples/...')
with open(CA_KEY_PEM, 'wb') as f:
    f.write(
        ca_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption(),
        )
    )
with open(CA_PEM, 'wb') as f:
    f.write(ca_cert.public_bytes(serialization.Encoding.PEM))
with open(SIGNER_KEY_PEM, 'wb') as f:
    f.write(
        signer_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption(),
        )
    )
with open(SIGNER_PEM, 'wb') as f:
    f.write(signer_cert.public_bytes(serialization.Encoding.PEM))

# 4) Create a small unsigned PDF using reportlab
LOG.info('Tạo PDF mẫu unsigned...')
canv = canvas.Canvas(str(UNSIGNED_PDF))
canv.setFont('Helvetica', 14)
canv.drawString(72, 720, 'This is a signed PDF sample created by create_signed_pdf.py')
canv.drawString(72, 700, 'Date: %s' % datetime.utcnow().isoformat())
canv.showPage()
canv.save()

# 5) Create a PKCS#12 keystore and invoke pyhanko CLI to sign the PDF.
LOG.info('Tạo PKCS#12 keystore cho signer...')
from cryptography.hazmat.primitives.serialization import pkcs12  # type: ignore

P12_PATH = SAMPLES / 'signer.p12'
P12_PASS = b'signerpass'
PASSFILE = SAMPLES / 'signer_pass.txt'
try:
    # Use password-protected PKCS#12 which pyhanko can load reliably.
    p12_data = pkcs12.serialize_key_and_certificates(
        name=b'signer',
        key=signer_key,
        cert=signer_cert,
        cas=[ca_cert],
        encryption_algorithm=serialization.BestAvailableEncryption(P12_PASS),
    )
    with open(P12_PATH, 'wb') as f:
        f.write(p12_data)
    with open(PASSFILE, 'wb') as f:
        f.write(P12_PASS)
except Exception as e:
    LOG.error('Không thể tạo PKCS#12: %s', e)
    raise

LOG.info('Ký PDF bằng pyhanko CLI...')
import subprocess
cmd = [
    str(Path(__file__).resolve().parents[1] / '.venv' / 'Scripts' / 'pyhanko.exe'),
    'sign', 'addsig',
    '--field', 'Signature1',
    'pkcs12',
    str(UNSIGNED_PDF),
    str(SIGNED_PDF),
    str(P12_PATH),
    '--passfile', str(PASSFILE),
]
LOG.info('Chạy: %s', ' '.join(cmd))
res = subprocess.run(cmd, capture_output=True, text=True)
LOG.debug('pyhanko stdout:\n%s', res.stdout)
LOG.debug('pyhanko stderr:\n%s', res.stderr)
if res.returncode != 0:
    LOG.error('pyhanko thất bại: %s', res.stderr)
    raise SystemExit(1)

LOG.info('Ký xong. Tạo file: %s', SIGNED_PDF)
print('Đã tạo:')
print(' - unsigned PDF:', UNSIGNED_PDF)
print(' - signed PDF:', SIGNED_PDF)
print(' - CA cert (trusted root):', CA_PEM)
print(' - signer cert/key:', SIGNER_PEM, SIGNER_KEY_PEM)

