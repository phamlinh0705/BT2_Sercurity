# Ghi chữ ký vào PDF (ghi chú)

*Thư mục này chứa một file mẫu `signed_sample.pdf` chưa thực sự được ký.* Để test end-to-end bạn cần một PDF đã được ký theo chuẩn PDF (CMS/PKCS#7 nhúng trong AcroForm signature dictionary).

Ghi chú nhanh để tạo PDF đã ký (tổng quan):

1. Chuẩn bị một PDF chưa ký (ví dụ `unsigned.pdf`).
2. Tạo trường chữ ký (signature field, AcroForm) trong PDF và để đủ không gian cho nội dung chữ ký (`/Contents`).
3. Tính toán các offset `/ByteRange` cho tài liệu nơi chữ ký sẽ được chèn.
4. Tạo PKCS#7 SignedData (detached) trên dữ liệu cần ký (theo ByteRange) bằng OpenSSL hoặc thư viện hỗ trợ:
   - `openssl cms -sign -binary -in data_to_sign.bin -signer signer.pem -inkey signer.key -certfile chain.pem -outform DER -out sig.p7s`
5. Chèn blob PKCS#7 vào trường `/Contents` của PDF (hex-encoded hoặc stream) và ghi file PDF bằng incremental update.

Các công cụ/thư viện hay dùng để ký PDF:
- Adobe Acrobat / Reader (giao diện)
- iText (Java/.NET)
- PDFBox + BouncyCastle
- PyHanko (Python) — thư viện Python hiện đại để ký PDF

Repo này KHÔNG cung cấp chức năng ký PDF hoàn chỉnh. Hãy dùng một trong các công cụ ở trên để tạo PDF đã ký phục vụ kiểm tra `verify_pdf_signature.py`.
