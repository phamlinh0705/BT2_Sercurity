from asn1crypto import cms, x509  # type: ignore
from cryptography import x509 as crypto_x509  # type: ignore
from cryptography.hazmat.backends import default_backend  # type: ignore

p='artifacts/extracted_pkcs7.der'
with open(p,'rb') as f:
    b=f.read()
ci = cms.ContentInfo.load(b)
sd = ci['content']
print('signer_infos count=', len(sd['signer_infos']))
for si in sd['signer_infos']:
    sid = si['sid']
    print('sid type:', sid.name)
    if sid.name == 'issuer_and_serial_number':
        issuer = sid.chosen['issuer']
        serial = sid.chosen['serial_number'].native
        print('  issuer:', issuer.human_friendly)
        print('  serial:', serial)
    else:
        print('  sid native:', sid.native)
    # dump signature algorithm
    print('  sig alg:', si['signature_algorithm'].native)
    print('  digest alg:', si['digest_algorithm'].native)
    print('  signature length:', len(si['signature'].native))
