<#
run_verify.ps1

PowerShell helper to create a venv, install requirements and run the verifier.
Usage examples (from project root `D:\security`):

# create venv, install deps and run verifier (PDF path required)
PS> .\scripts\run_verify.ps1 -Pdf .\samples\signed_sample.pdf

# run with trusted roots and custom logdir
PS> .\scripts\run_verify.ps1 -Pdf .\samples\signed_sample.pdf -TrustedRoots .\certs\roots.pem -LogDir .\logs

This script attempts to be robust to ExecutionPolicy restrictions by setting the policy
for the current process only (no permanent system changes).
#>
param(
    [Parameter(Mandatory=$true)]
    [string] $Pdf,

    [string] $TrustedRoots,
    [string] $Crl,
    [string] $LogDir = ".\logs",

    [switch] $RecreateVenv
)

# Helper: remove .venv safely
function Remove-Venv {
    if (Test-Path -LiteralPath '.venv') {
        Write-Host "Xóa .venv (Remove-Item -Recurse -Force) ..."
        Remove-Item -LiteralPath '.venv' -Recurse -Force -ErrorAction Stop
    }
}

try {
    if ($RecreateVenv) {
        Remove-Venv
    }
} catch {
    Write-Warning "Không thể xóa .venv: $_"
}

# Determine which Python launcher to use and create venv if missing.
# Prefer system 'python' if it runs, otherwise try 'py -3'.
$pythonLauncher = 'python'
try {
    & $pythonLauncher -V > $null 2>&1
} catch {
    # try py -3
    $pythonLauncher = 'py -3'
    try {
        & $pythonLauncher -V > $null 2>&1
    } catch {
        Write-Error "Không tìm thấy Python ('python' hoặc 'py -3'). Cài Python hoặc sửa PATH."; exit 3
    }
}

# Create venv if missing using the selected launcher
if (-not (Test-Path -LiteralPath '.venv')) {
    Write-Host "Tạo virtualenv .venv bằng: $pythonLauncher ..."
    & $pythonLauncher -m venv .venv
}

# Use venv's python executable path
$venvPython = Join-Path -Path (Resolve-Path -Path '.venv').Path -ChildPath 'Scripts\python.exe'
if (-not (Test-Path $venvPython)) {
    Write-Error "Không tìm thấy python trong .venv (đường dẫn: $venvPython). Kiểm tra xem venv đã được tạo đúng chưa."
    exit 2
}

# Upgrade pip and install requirements with venv python (no need to Activate.ps1)
Write-Host "Cài yêu cầu từ requirements.txt vào venv..."
& $venvPython -m pip install --upgrade pip
& $venvPython -m pip install -r .\requirements.txt

# Run the verifier with venv python
$cmd = @($venvPython, '.\scripts\verify_pdf_signature.py', '--pdf', $Pdf, '--logdir', $LogDir)
if ($TrustedRoots) { $cmd += @('--trusted-roots', $TrustedRoots) }
if ($Crl) { $cmd += @('--crl', $Crl) }

Write-Host "Chạy verifier..."
& $cmd

if ($LASTEXITCODE -ne 0) {
    Write-Warning "Verifier thoát với mã lỗi $LASTEXITCODE"
} else {
    Write-Host "Hoàn tất. Kiểm tra logs trong: $LogDir (hoặc logs/verify_*.log)"
}
