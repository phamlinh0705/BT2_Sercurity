from asn1crypto import cms, x509  # type: ignore
from cryptography import x509 as crypto_x509  # type: ignore
from cryptography.hazmat.backends import default_backend  # type: ignore

p='artifacts/extracted_pkcs7.der'
with open(p,'rb') as f:
    b=f.read()
ci = cms.ContentInfo.load(b)
sd = ci['content']
if sd['certificates'] is None:
    print('no certs')
else:
    for c in sd['certificates']:
        if isinstance(c.chosen, x509.Certificate):
            der=c.chosen.dump()
            cert = crypto_x509.load_der_x509_certificate(der, default_backend())
            print('Subject:', cert.subject.rfc4514_string())
            try:
                bc = cert.extensions.get_extension_for_class(crypto_x509.BasicConstraints).value
                print('  basicConstraints.ca=', bc.ca)
            except Exception as e:
                print('  no basicConstraints or error:', e)
