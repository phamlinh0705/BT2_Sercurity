# Project: PDF Signed Verification (Python)

Tài liệu ngắn (tiếng Việt)

Mục tiêu
- Tạo một mẫu PDF có chữ ký PKCS#7 (PDF signature) bằng Python (không dùng OpenSSL).
- Viết script kiểm tra chữ ký trong PDF: tách /Contents, so sánh messageDigest, kiểm tra chữ ký và chuỗi chứng chỉ.

Nội dung repository
- `scripts/create_signed_pdf.py`: tạo CA test, tạo signer (end-entity) với keyUsage phù hợp, tạo PDF unsigned và ký bằng `pyhanko` (tạo `samples/signed_by_pyhanko.pdf`).
- `scripts/verify_pdf_signature.py`: verifier chính. Tách ByteRange/Contents, trích PKCS#7, so sánh `messageDigest`, cố gắng xác thực chữ ký bằng `cryptography`, sử dụng `certvalidator` (nếu có) để dựng đường dẫn, và gọi `pyhanko` CLI như validator tham chiếu. Có fallback đơn giản (direct root signature verify) dành cho CA thử nghiệm.
- `samples/`: chứa CA (`ca.pem`), signer cert/key, PKCS#12, unsigned & signed PDF.
- `artifacts/extracted_pkcs7.der`: PKCS#7 đã tách từ PDF (mỗi lần chạy sẽ ghi đè).
- `logs/`: các log chạy verifier và pyhanko.

Yêu cầu cài đặt
- Python 3.8+ (đã dùng virtualenv trong `.venv`).
- Cài dependencies (nên cài trong virtualenv):

```powershell
.\.venv\Scripts\python -m pip install -r requirements.txt
```

Nếu bạn chỉ muốn chạy nhanh ở môi trường này (đã cài sẵn trong `.venv` khi mình thực hiện), dùng lệnh Python trực tiếp.

Các bước chính (PowerShell)

1) Tạo và ký PDF (sẽ tạo/ghi đè `samples/signed_by_pyhanko.pdf`):

```powershell
python .\scripts\create_signed_pdf.py
```

2) Kiểm tra chữ ký bằng verifier (sử dụng `samples/ca.pem` làm trusted root):

```powershell
python .\scripts\verify_pdf_signature.py --pdf .\samples\signed_by_pyhanko.pdf --trusted-roots .\samples\ca.pem --logdir .\logs
```

3) Kết quả và logs
- Kết quả chạy sẽ in ra console và ghi log chi tiết vào `logs/verify_YYYYMMDDTHHMMSSZ.log`.
- Nếu `pyhanko` xác nhận là `cryptographically sound` và có đường dẫn tới trust anchor thì verifier in `KẾT LUẬN: XÁC THỰC THÀNH CÔNG`.
- Trong môi trường test, nếu chứng chỉ signer thiếu extension/policy, script có fallback: kiểm tra trực tiếp rằng `ca.pem` đã ký signer cert (chỉ dùng cho mục đích thử nghiệm).

Ghi chú kỹ thuật và caveats
- `pyhanko` thực hiện path-building và áp policy (keyUsage/extendedKeyUsage). Để pyhanko chấp nhận, signer certificate cần có các extension phù hợp (ví dụ `keyUsage` chứa `digitalSignature` và/hoặc `nonRepudiation`). Mình đã chỉnh `create_signed_pdf.py` để thêm `KeyUsage(digitalSignature, contentCommitment)`.
- `certvalidator` được tích hợp như một bước tùy chọn để dựng đường dẫn chứng chỉ (nếu package có sẵn trong môi trường). Nếu không, script dùng fallback đơn giản.
- Không dùng OpenSSL: toàn bộ flow ký/kiểm tra được làm bằng Python + `pyhanko`.

Files to submit (được đóng gói trong `submission.zip`):
- scripts/*
- samples/*
- logs/*
- artifacts/*

Liên hệ / tiếp theo
- Nếu bạn muốn mình bổ sung README tiếng Anh, hoặc thêm test unit, hoặc thay đổi policy (ví dụ bắt buộc OCSP/CRL), báo mình biết.

----
Ngắn gọn: để tái hiện toàn bộ pipeline, chạy `create_signed_pdf.py` rồi `verify_pdf_signature.py` như hướng dẫn ở trên. README này được lưu ở `D:\security\README.md`.
## Xác thực chữ ký PDF (Bài tập)

Kho chứa một script Python thực hiện kiểm tra chữ ký số nhúng trong PDF theo yêu cầu bài tập.

Các bước kiểm tra mà script thực hiện:

1. Đọc Signature dictionary: `/Contents`, `/ByteRange`.
2. Tách PKCS#7 từ `/Contents` và kiểm tra định dạng.
3. Tính hàm băm (hash) trên phạm vi `/ByteRange` và so sánh với `messageDigest` trong signed attributes.
4. Xác thực chữ ký bằng public key trong chứng chỉ của signer.
5. Kiểm tra chuỗi chứng chỉ (chain) lên tới Root CA tin cậy.
6. Kiểm tra tình trạng thu hồi (OCSP/CRL) nếu có dữ liệu/URL.
7. Kiểm tra token dấu thời gian (timestamp token) nếu có.
8. Kiểm tra incremental update để phát hiện sửa đổi sau khi đã ký.

File chính:

- `scripts/verify_pdf_signature.py` — script thực hiện các bước cốt lõi (trích xuất, phân tích PKCS#7, kiểm tra `messageDigest`, xác minh chữ ký, kiểm tra chain cơ bản, CRL tùy chọn, phát hiện timestamp, kiểm tra incremental-update). Kết quả sẽ được ghi vào file log.

Hướng dẫn nhanh (Windows PowerShell):

1. Tạo virtualenv và cài dependencies:

```powershell
python -m venv .venv; .\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

2. Chạy verifier:

```powershell
python .\scripts\verify_pdf_signature.py --pdf .\samples\signed_sample.pdf --trusted-roots .\certs\roots.pem --logdir .\logs
```

Ghi chú:
- Script cố gắng thực hiện đầy đủ các bước nêu trên. Một số bước (OCSP, CRL, timestamp token) có thể cần dữ liệu bổ sung (file CRL, URL OCSP, quyền truy cập mạng) để kiểm tra hoàn chỉnh.
- `samples/signed_sample.pdf` trong repo chỉ là mẫu placeholder; để kiểm tra end-to-end bạn cần một PDF đã được ký thực tế.

Xem `scripts/verify_pdf_signature.py` để biết chi tiết tham số CLI và mô tả các bước kiểm tra.