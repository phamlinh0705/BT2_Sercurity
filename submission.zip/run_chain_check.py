from verify_pdf_signature import load_trusted_roots, parse_pkcs7_and_verify

# This script simply runs parse_pkcs7_and_verify on the extracted PKCS7 and prints result
if __name__ == '__main__':
    import os
    pk = os.path.join('artifacts','extracted_pkcs7.der')
    # load the pkcs7 and pass empty signed_data (not used for chain check here)
    with open(pk,'rb') as f:
        pkcs7 = f.read()
    ok = parse_pkcs7_and_verify(pkcs7, b'', 'samples/ca.pem', None)
    print('parse_pkcs7_and_verify returned', ok)
