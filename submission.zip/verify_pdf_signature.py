#!/usr/bin/env python3
"""verify_pdf_signature.py

Nhẹ, tự động: trích PKCS#7 từ /Contents trong PDF, so sánh messageDigest,
thử verify chữ ký bằng các cert đính kèm và (nếu có) gọi pyhanko để làm
validator tham chiếu. Ghi log chi tiết vào thư mục logs/.
"""

from typing import List, Tuple, Optional
import argparse
import logging
import os
import re
import binascii
import subprocess
import shutil
from datetime import datetime

try:
    from asn1crypto import cms, x509 as asn1_x509  # type: ignore
except Exception:
    cms = None
    asn1_x509 = None

from cryptography import x509 as crypto_x509  # type: ignore
from cryptography.hazmat.primitives import hashes  # type: ignore
from cryptography.hazmat.primitives.asymmetric import padding  # type: ignore
from cryptography.hazmat.backends import default_backend  # type: ignore
from cryptography.hazmat.primitives.serialization import Encoding  # type: ignore

try:
    # certvalidator is optional; use it for proper path-building when available
    from certvalidator import CertificateValidator, ValidationContext  # type: ignore
except Exception:
    CertificateValidator = None
    ValidationContext = None

LOGGER = logging.getLogger("verify_pdf_signature")

# Regexes for ByteRange and hex Contents
BYTE_RANGE_RE = re.compile(rb"/ByteRange\s*\[\s*(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s*\]")
CONTENTS_HEX_RE = re.compile(rb"/Contents\s*<([0-9A-Fa-f\s\r\n]+)>")


def setup_logging(logdir: str) -> str:
    os.makedirs(logdir, exist_ok=True)
    ts = datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')
    logfile = os.path.join(logdir, f'verify_{ts}.log')

    # Clear previous handlers
    for h in list(LOGGER.handlers):
        LOGGER.removeHandler(h)

    fh = logging.FileHandler(logfile, encoding='utf-8')
    fh.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
    LOGGER.addHandler(fh)

    ch = logging.StreamHandler()
    ch.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
    LOGGER.addHandler(ch)

    LOGGER.setLevel(logging.DEBUG)
    return logfile


def extract_byte_range_and_contents(pdf_bytes: bytes) -> Tuple[List[int], bytes]:
    m = BYTE_RANGE_RE.search(pdf_bytes)
    if not m:
        raise ValueError('Không tìm thấy /ByteRange trong PDF')
    br = [int(m.group(i)) for i in range(1, 5)]
    LOGGER.debug(f'Tìm thấy ByteRange: {br}')

    m2 = CONTENTS_HEX_RE.search(pdf_bytes)
    if m2:
        hex_str = re.sub(rb"\s+", b"", m2.group(1))
        LOGGER.debug(f'Độ dài hex của Contents đã trích xuất={len(hex_str)}')
        pkcs7 = binascii.unhexlify(hex_str)
        pkcs7 = pkcs7.rstrip(b"\x00")
        LOGGER.debug(f'Độ dài blob PKCS#7 sau khi cắt đuôi={len(pkcs7)}')
        return br, pkcs7

    # fallback: look for stream content after /Contents
    idx = pdf_bytes.find(b"/Contents")
    if idx == -1:
        raise ValueError('Không tìm thấy /Contents trong PDF')
    stream_idx = pdf_bytes.find(b"stream", idx)
    if stream_idx == -1:
        raise ValueError('Không tìm thấy nội dung /Contents ở dạng hex hoặc stream')
    start = stream_idx + len(b"stream")
    endstream = pdf_bytes.find(b"endstream", start)
    if endstream == -1:
        raise ValueError("Không tìm thấy 'endstream' sau Contents")
    content = pdf_bytes[start:endstream].lstrip(b"\r\n")
    LOGGER.debug(f'Đã trích xuất nội dung stream, độ dài={len(content)}')
    return br, content


def build_signed_data(pdf_bytes: bytes, br: List[int]) -> bytes:
    a = pdf_bytes[br[0]:br[0] + br[1]]
    b = pdf_bytes[br[2]:br[2] + br[3]]
    LOGGER.debug(f'Độ dài hai phần theo ByteRange: {len(a)}, {len(b)}')
    return a + b


def get_hash_algorithm(name: str):
    n = (name or '').lower().replace('-', '')
    if 'sha256' in n:
        return hashes.SHA256()
    if 'sha1' in n:
        return hashes.SHA1()
    if 'sha384' in n:
        return hashes.SHA384()
    if 'sha512' in n:
        return hashes.SHA512()
    if 'md5' in n:
        return hashes.MD5()
    raise ValueError(f'Unsupported hash algorithm: {name}')


def load_trusted_roots(pem_path: str) -> List[crypto_x509.Certificate]:
    with open(pem_path, 'rb') as f:
        data = f.read()
    certs: List[crypto_x509.Certificate] = []
    blocks = data.split(b'-----END CERTIFICATE-----')
    for block in blocks:
        if b'-----BEGIN CERTIFICATE-----' in block:
            block = block + b'-----END CERTIFICATE-----'
            cert = crypto_x509.load_pem_x509_certificate(block, default_backend())
            certs.append(cert)
    LOGGER.debug(f'Tải được {len(certs)} chứng chỉ root tin cậy')
    return certs


def basic_chain_verify(chain_certs: List[crypto_x509.Certificate], trusted_roots: List[crypto_x509.Certificate]) -> bool:
    if not chain_certs:
        LOGGER.warning('Không có chứng chỉ trong PKCS#7 để kiểm tra chuỗi')
        return False

    # choose leaf (prefer non-CA)
    leaf = None
    for c in chain_certs:
        try:
            bc = c.extensions.get_extension_for_class(crypto_x509.BasicConstraints).value
            if not bc.ca:
                leaf = c
                break
        except Exception:
            leaf = c
            break
    if leaf is None:
        leaf = chain_certs[0]

    current = leaf
    for _ in range(10):
        issuer = current.issuer
        subject = current.subject
        LOGGER.debug(f'Bước chuỗi: subject={subject.rfc4514_string()} issuer={issuer.rfc4514_string()}')
        if issuer.rfc4514_string() == subject.rfc4514_string():
            # self-signed
            for root in trusted_roots:
                if root.subject.rfc4514_string() == issuer.rfc4514_string():
                    try:
                        root.public_key().verify(
                            current.signature,
                            current.tbs_certificate_bytes,
                            padding.PKCS1v15(),
                            current.signature_hash_algorithm,
                        )
                        LOGGER.info('Chuỗi chứng chỉ hợp lệ đến root tự ký (trusted)')
                        return True
                    except Exception as e:
                        LOGGER.warning(f'Xác minh chữ ký bởi root thất bại: {e}')
                        return False
            LOGGER.warning('Đã gặp chứng chỉ tự ký nhưng không thuộc trusted roots')
            return False

        # find issuer in chain or trusted
        issuer_cert = None
        for c in chain_certs:
            if c.subject.rfc4514_string() == issuer.rfc4514_string():
                issuer_cert = c
                break
        if issuer_cert is None:
            for root in trusted_roots:
                if root.subject.rfc4514_string() == issuer.rfc4514_string():
                    issuer_cert = root
                    break
        if issuer_cert is None:
            LOGGER.warning('Không tìm thấy chứng chỉ issuer cho: %s', issuer.rfc4514_string())
            return False

        try:
            issuer_cert.public_key().verify(
                current.signature,
                current.tbs_certificate_bytes,
                padding.PKCS1v15(),
                current.signature_hash_algorithm,
            )
            LOGGER.debug('Xác minh chữ ký chứng chỉ bởi issuer thành công')
        except Exception as e:
            LOGGER.warning(f'Xác minh chữ ký chứng chỉ thất bại: {e}')
            return False

        if issuer_cert in trusted_roots:
            LOGGER.info('Chuỗi chứng chỉ hợp lệ tới trusted root')
            return True
        current = issuer_cert
    LOGGER.warning('Vượt quá độ sâu chuỗi khi xác minh')
    return False


def parse_pkcs7_and_verify(pkcs7_bytes: bytes, signed_data_bytes: bytes, trusted_roots_pem: Optional[str], crl_pem: Optional[str]):
    if cms is None:
        raise RuntimeError('asn1crypto không sẵn có; không thể phân tích PKCS#7')
    content_info = cms.ContentInfo.load(pkcs7_bytes)
    if content_info['content_type'].native != 'signed_data':
        raise ValueError('Nội dung PKCS#7 không phải signedData')
    sd = content_info['content']

    certs: List[crypto_x509.Certificate] = []
    if sd['certificates'] is not None:
        for c in sd['certificates']:
            if isinstance(c.chosen, asn1_x509.Certificate):
                cert = crypto_x509.load_der_x509_certificate(c.chosen.dump(), default_backend())
                certs.append(cert)
    LOGGER.info(f'PKCS#7 chứa {len(certs)} chứng chỉ')

    signer_infos = sd['signer_infos']
    if len(signer_infos) == 0:
        raise ValueError('Không có signer info trong SignedData')
    signer = signer_infos[0]

    signed_attrs = signer['signed_attrs']
    msg_digest = None
    if signed_attrs is not None:
        for attr in signed_attrs:
            if attr['type'].dotted == '1.2.840.113549.1.9.4':
                msg_digest = bytes(attr['values'][0].native)
                LOGGER.debug(f'Độ dài messageDigest attribute: {len(msg_digest)}')

    digest_name = signer['digest_algorithm']['algorithm'].native
    hash_alg = get_hash_algorithm(digest_name)
    digest = hashes.Hash(hash_alg, backend=default_backend())
    digest.update(signed_data_bytes)
    computed = digest.finalize()
    LOGGER.info(f'Digest tính toán ({digest_name}): {computed.hex()}')
    if msg_digest is None:
        LOGGER.warning('Không tìm thấy thuộc tính messageDigest trong signed attributes')
    else:
        LOGGER.info(f'messageDigest từ signed_attrs: {msg_digest.hex()}')
        if computed != msg_digest:
            LOGGER.error('messageDigest không khớp: computed != signed_attrs')
            return False, certs
        LOGGER.info('messageDigest khớp với giá trị tính toán')

    # Try to locate signer cert via sid
    sid = signer['sid']
    signer_cert = None
    if sid.name == 'issuer_and_serial_number':
        issuer = sid.chosen['issuer']
        serial = sid.chosen['serial_number'].native
        issuer_dn = issuer.human_friendly
        for c in certs:
            if c.serial_number == serial and c.issuer.rfc4514_string() == issuer_dn:
                signer_cert = c
                break

    if signer_cert is None:
        # fallback: choose a non-CA cert from certs
        chosen = None
        for c in certs:
            try:
                bc = c.extensions.get_extension_for_class(crypto_x509.BasicConstraints).value
                if not bc.ca:
                    chosen = c
                    break
            except Exception:
                chosen = c
                break
        if chosen is None and certs:
            chosen = certs[0]
            LOGGER.warning('Không thể phân giải signer cert qua sid; sử dụng cert đầu tiên trong PKCS#7')
        signer_cert = chosen

    if signer_cert is None:
        raise ValueError('No signer certificate available')

    LOGGER.info(f'Sử dụng chứng chỉ signer subject={signer_cert.subject.rfc4514_string()}')

    signed_attrs_der = signed_attrs.dump() if signed_attrs is not None else b''
    signature_bytes = signer['signature'].native
    crypto_hash = get_hash_algorithm(digest_name)

    verified = False
    verification_error = None
    for c in certs:
        pubkey = c.public_key()
        try:
            pubkey.verify(
                signature_bytes,
                signed_attrs_der,
                padding.PKCS1v15(),
                crypto_hash,
            )
            LOGGER.info(f'Xác thực chữ ký thành công (PKCS#1 v1.5) bằng cert={c.subject.rfc4514_string()}')
            signer_cert = c
            verified = True
            break
        except Exception as e1:
            try:
                pubkey.verify(
                    signature_bytes,
                    signed_attrs_der,
                    padding.PSS(mgf=padding.MGF1(crypto_hash), salt_length=padding.PSS.MAX_LENGTH),
                    crypto_hash,
                )
                LOGGER.info(f'Xác thực chữ ký thành công (PSS) bằng cert={c.subject.rfc4514_string()}')
                signer_cert = c
                verified = True
                break
            except Exception as e2:
                verification_error = e2
                LOGGER.debug(f'Chứng chỉ {c.subject.rfc4514_string()} không xác thực được (v1.5: {e1}; pss: {e2})')

    if not verified:
        LOGGER.error(f'Xác thực chữ ký thất bại: {verification_error}')
        return False, certs

    # basic chain verification (best-effort)
    if trusted_roots_pem:
        trusted = load_trusted_roots(trusted_roots_pem)
        chain_ok = basic_chain_verify(certs, trusted)
        if chain_ok:
            LOGGER.info('Kiểm tra chuỗi chứng chỉ (basic): OK')
        else:
            LOGGER.warning('Kiểm tra chuỗi chứng chỉ (basic) thất bại hoặc chưa đầy đủ; thử certvalidator nếu có')
            # Try certvalidator for proper path-building if available
            if CertificateValidator is not None:
                try:
                    # build DER blobs
                    end_entity_der = signer_cert.public_bytes(Encoding.DER)
                    intermediates = [c.public_bytes(Encoding.DER) for c in certs if c.serial_number != signer_cert.serial_number]
                    trust_roots = [r.public_bytes(Encoding.DER) for r in trusted]
                    ctx = ValidationContext(trust_roots=trust_roots, allow_fetching=False)
                    validator = CertificateValidator(end_entity_der, intermediate_certs=intermediates, validation_context=ctx)
                    # perform validation (no specific usage enforced here)
                    path = validator.validate_usage(set())
                    LOGGER.info('certvalidator: Path built, validation OK')
                    chain_ok = True
                except Exception as e:
                    LOGGER.warning(f'certvalidator failed to validate chain: {e}')
                    chain_ok = False
            else:
                LOGGER.debug('certvalidator không có sẵn trong môi trường; bỏ qua bước này')
        if chain_ok:
            LOGGER.info('Kiểm tra chuỗi chứng chỉ: OK')
        else:
            LOGGER.warning('Kiểm tra chuỗi chứng chỉ: THẤT BẠI hoặc chưa đầy đủ')
    else:
        LOGGER.warning('Chưa cung cấp trusted roots; bỏ qua kiểm tra chuỗi')

    # CRL check (optional)
    if crl_pem and signer_cert is not None:
        try:
            with open(crl_pem, 'rb') as f:
                from cryptography.x509 import load_pem_x509_crl  # type: ignore
                crl = load_pem_x509_crl(f.read(), default_backend())
            serial = signer_cert.serial_number
            for revoked in crl:
                if revoked.serial_number == serial:
                    LOGGER.error('Chứng chỉ signer ĐÃ BỊ THU HỒI theo CRL cung cấp')
                    return False, certs
            LOGGER.info('Kiểm tra CRL: không bị thu hồi (theo CRL cung cấp)')
        except Exception as e:
            LOGGER.warning(f'Kiểm tra CRL thất bại: {e}')

    # timestamp token detection
    ts_presence = False
    if signed_attrs is not None:
        for attr in signed_attrs:
            if attr['type'].dotted == '1.2.840.113549.1.9.16.2.14':
                ts_presence = True
                LOGGER.info('Tìm thấy thuộc tính signatureTimeStampToken (có timestamp token)')
    if not ts_presence:
        LOGGER.info('Không tìm thấy thuộc tính timestamp token')

    return True, certs


def detect_incremental_update(pdf_len: int, br: List[int]) -> bool:
    covered = set(range(br[0], br[0] + br[1])) | set(range(br[2], br[2] + br[3]))
    if len(covered) < pdf_len:
        LOGGER.warning('Tệp PDF có bytes ngoài ByteRange — có thể là incremental update hoặc nội dung bị thêm vào')
        return True
    LOGGER.info('ByteRange bao phủ toàn bộ tệp (heuristic)')
    return False


def main():
    parser = argparse.ArgumentParser(description='Xác thực chữ ký PKCS#7 nhúng trong PDF (cơ bản)')
    parser.add_argument('--pdf', required=True, help='Tệp PDF cần kiểm tra')
    parser.add_argument('--trusted-roots', help='File PEM chứa chứng chỉ Root CA tin cậy')
    parser.add_argument('--crl', help='File PEM chứa CRL để kiểm tra')
    parser.add_argument('--logdir', default='logs', help='Thư mục lưu log')
    args = parser.parse_args()

    logfile = setup_logging(args.logdir)
    LOGGER.info(f'Đang kiểm tra PDF: {args.pdf}')

    pdf_path = os.path.abspath(args.pdf)
    pdf_bytes = open(pdf_path, 'rb').read()
    try:
        br, pkcs7 = extract_byte_range_and_contents(pdf_bytes)
    except Exception as e:
        LOGGER.error(f'Không thể trích xuất ByteRange/Contents: {e}')
        return

    signed_data_bytes = build_signed_data(pdf_bytes, br)

    os.makedirs('artifacts', exist_ok=True)
    pkcs7_path = os.path.join('artifacts', 'extracted_pkcs7.der')
    with open(pkcs7_path, 'wb') as f:
        f.write(pkcs7)
    LOGGER.info(f'Đã ghi PKCS#7 tách ra vào {pkcs7_path}')

    try:
        ok, pkcs7_certs = parse_pkcs7_and_verify(pkcs7, signed_data_bytes, args.trusted_roots, args.crl)
    except Exception as e:
        LOGGER.exception(f'Lỗi khi phân tích / xác minh PKCS#7: {e}')
        ok = False
        pkcs7_certs = []

    # Try pyhanko validator if available for authoritative check
    pyhanko_path = None
    try:
        venv_pyhanko = os.path.join('.venv', 'Scripts', 'pyhanko.exe')
        if os.path.exists(venv_pyhanko):
            pyhanko_path = venv_pyhanko
        else:
            pyhanko_path = shutil.which('pyhanko')
    except Exception:
        pyhanko_path = None

    if pyhanko_path:
        LOGGER.info('Chạy pyhanko validator để kiểm tra CMS/PDF (nếu có)')
        cmd = [pyhanko_path, 'sign', 'validate', '--pretty-print', pdf_path]
        if args.trusted_roots:
            cmd = [pyhanko_path, 'sign', 'validate', '--pretty-print', '--trust-replace', '--trust', args.trusted_roots, '--no-revocation-check', pdf_path]
        try:
            res = subprocess.run(cmd, capture_output=True, text=True)
            LOGGER.debug('pyhanko stdout:\n' + (res.stdout or ''))
            LOGGER.debug('pyhanko stderr:\n' + (res.stderr or ''))
            if res.returncode == 0:
                LOGGER.info('pyhanko: Validation OK — chữ ký cryptographically & chain đều hợp lệ')
                LOGGER.info('KẾT LUẬN: XÁC THỰC THÀNH CÔNG')
            else:
                LOGGER.warning('pyhanko: Validation báo lỗi/không hợp lệ')
                LOGGER.warning(res.stdout)
                LOGGER.warning(res.stderr)
                # fallback: if pyhanko says integrity OK but chain failed, try simple direct root verify
                if ('cryptographically sound' in (res.stdout or '') or 'cryptographically sound' in (res.stderr or '')) and args.trusted_roots and pkcs7_certs:
                    try:
                        trusted = load_trusted_roots(args.trusted_roots)
                        signer_candidate = None
                        for c in pkcs7_certs:
                            try:
                                bc = c.extensions.get_extension_for_class(crypto_x509.BasicConstraints).value
                                if not bc.ca:
                                    signer_candidate = c
                                    break
                            except Exception:
                                signer_candidate = c
                                break
                        if signer_candidate is None:
                            LOGGER.error('Không tìm thấy chứng chỉ signer trong PKCS#7 (fallback)')
                        else:
                            issuer_dn = signer_candidate.issuer.rfc4514_string()
                            root_candidate = None
                            for r in trusted:
                                if r.subject.rfc4514_string() == issuer_dn:
                                    root_candidate = r
                                    break
                            if root_candidate is None:
                                LOGGER.warning('Không tìm thấy trusted root khớp issuer của signer (fallback)')
                            else:
                                try:
                                    root_candidate.public_key().verify(
                                        signer_candidate.signature,
                                        signer_candidate.tbs_certificate_bytes,
                                        padding.PKCS1v15(),
                                        signer_candidate.signature_hash_algorithm,
                                    )
                                    LOGGER.info('Fallback: trusted root xác minh chữ ký signer thành công -> chấp nhận')
                                    LOGGER.info('KẾT LUẬN: XÁC THỰC THÀNH CÔNG (fallback)')
                                except Exception as e:
                                    LOGGER.warning('Fallback verification by trusted root thất bại: %s', e)
                                    LOGGER.error('KẾT LUẬN: XÁC THỰC THẤT BẠI (pyhanko)')
                    except Exception as e:
                        LOGGER.warning('Lỗi khi chạy fallback chain verify: %s', e)
                        LOGGER.error('KẾT LUẬN: XÁC THỰC THẤT BẠI (pyhanko)')
                else:
                    LOGGER.error('KẾT LUẬN: XÁC THỰC THẤT BẠI (pyhanko)')
        except FileNotFoundError:
            LOGGER.warning('Không tìm thấy pyhanko để chạy validator; dùng verifier nội bộ')
            if ok:
                LOGGER.info('KẾT LUẬN: XÁC THỰC THÀNH CÔNG (bằng verifier nội bộ)')
            else:
                LOGGER.error('KẾT LUẬN: XÁC THỰC THẤT BẠI (bằng verifier nội bộ)')
    else:
        if ok:
            LOGGER.info('KẾT LUẬN: XÁC THỰC THÀNH CÔNG')
        else:
            LOGGER.error('KẾT LUẬN: XÁC THỰC THẤT BẠI')

    detect_incremental_update(len(pdf_bytes), br)
    LOGGER.info(f'Log đã ghi vào {logfile}')


if __name__ == '__main__':
    main()
